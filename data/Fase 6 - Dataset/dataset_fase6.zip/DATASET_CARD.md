# Dataset card · FarmTech Fase 6 (xicara × tesoura)
> Gerado automaticamente pela ferramenta de preparo em 11/10/2026 14:52.

## Motivação
Conjunto criado para treinar e avaliar um detector de objetos (YOLOv5) na Fase 6 do curso de IA da FIAP, demonstrando visão computacional ao cliente fictício FarmTech Solutions.

## Composição
| Etapa | xicara | tesoura | Total |
|---|---|---|---|
| train | 32 | 32 | 64 |
| val | 4 | 4 | 8 |
| test | 4 | 4 | 8 |

- Formato: JPG, maior lado de 1280 px (média de 1028 × 1212 px), um objeto por imagem.
- Rótulos: formato YOLO (classe, centro e tamanho normalizados), um `.txt` por imagem; classes em `classes.txt`.
- Tamanho dos objetos: em média 48% da área da foto (de 27% a 65%).

## Coleta
Fotos tiradas pelo grupo com celular, em ambiente doméstico, variando fundo, ângulo, distância e iluminação. 0 foto(s) vieram em HEIC e foram convertidas. A rotação do EXIF foi aplicada nos pixels e os metadados (inclusive localização) foram removidos.

## Rotulação
Caixas delimitadoras feitas no Make Sense AI e exportadas em YOLO. As caixas foram **pré-sugeridas automaticamente** (COCO e U²-Net) e **revisadas uma a uma** no Make Sense. A ferramenta de preparo validou todos os rótulos (formato, coordenadas e classe conferida pelo nome do arquivo). Evidências: `assets/makesense/` no repositório.

## Divisão
32 / 4 / 4 imagens por classe (treino / validação / teste), sorteadas com semente fixa (42). O mapa entre foto original e nome final está em `mapa_nomes.csv`.

## Limitações
Poucas imagens, um único ambiente e um objeto por foto: o conjunto serve para demonstração e estudo, não para produção.

## Privacidade e licença
Sem pessoas, rostos, documentos ou placas. Metadados removidos. Licença **CC BY 4.0**: pode ser reutilizado com crédito ao grupo.


## Limitação metodológica: origem das caixas

As caixas inicialmente sugeridas automaticamente por ferramentas de segmentação/detecção (COCO e U²-Net) foram revisadas antes da exportação. Isso não equivale a uma rotulação totalmente independente feita do zero. Como o YOLO pré-treinado usa COCO, as sugestões baseadas em COCO podem introduzir viés favorável ao modelo YOLO na comparação. Essa possibilidade é registrada como limitação; não deve ser interpretada como prova de superioridade.

As capturas de tela do Make Sense AI que documentam a revisão das caixas e a exportação YOLO ficam na pasta `assets/makesense/` do repositório.
